package com.doosinc.platforma.data.parcelables;

import android.os.Parcel;
import android.os.Parcelable;

import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.ContentSrc;

public class  ContentParcelable implements Parcelable {
    private int id;
    private String descr;
    private String date;
    private String src;
    private String tmb;
    private Content.ContentType type;

    public ContentParcelable(Content content) {
        id = content.getId();
        descr = content.getDescr();
        date = content.getDate();

        ContentSrc image = content.getImage();
        if (image != null) {
            src = image.getSrc();
            tmb = image.getTmb();
        }
        type = content.getType();
    }

    private ContentParcelable(Parcel in) {
        id = in.readInt();
        descr = in.readString();
        date = in.readString();
        src = in.readString();
        tmb = in.readString();
        type =  Content.ContentType.getType(in.readString());
    }

    public static final Creator<ContentParcelable> CREATOR = new Creator<ContentParcelable>() {
        @Override
        public ContentParcelable createFromParcel(Parcel in) {
            return new ContentParcelable(in);
        }

        @Override
        public ContentParcelable[] newArray(int size) {
            return new ContentParcelable[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(descr);
        dest.writeString(date);
        dest.writeString(src);
        dest.writeString(tmb);
        dest.writeString(type.getType());
    }

    public int getId() {
        return id;
    }

    public String getDescr() {
        return descr;
    }

    public String getDate() { return date; }

    public String getSrc() {
        return src;
    }

    public String getTmb() {
        return tmb;
    }

    public Content.ContentType getType() {
        return type;
    }
}