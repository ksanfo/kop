package com.doosinc.platforma.pages;

import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager2.widget.ViewPager2;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.ContentPages;

import com.doosinc.platforma.data.models.Content;

import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.pages.fragments.ContentsListFragment;
import com.doosinc.platforma.router.Router;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;


public class  ContentsPage extends AppCompatActivity implements ContentsListFragment.UpdatePage {
    Project project;
    Line line;
    String dayWithContent;
    Toolbar toolbar;
    ContentPages pageAdapter;
    Content.ContentType type;
    ViewPager2 pager;
    int pagerCurrentItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contents_page);

        Bundle argument = getIntent().getExtras();
        if (argument == null) {
            return;
        } else {
            project = (Project) argument.getSerializable(Project.class.getSimpleName());
            line = (Line) argument.getSerializable(Line.class.getSimpleName());
            dayWithContent = argument.getString("day");
            pagerCurrentItem = argument.getInt("pagerCurrentItem", 0);
        }

        toolbar = findViewById(R.id.toolbar);
        initActionBar();

        pager = findViewById(R.id.contentPages);
        doPageAdapter(dayWithContent, pagerCurrentItem);

        TabLayout contentMenu = findViewById(R.id.contentMenu);
        @SuppressWarnings("Convert2Lambda")
        TabLayoutMediator tabLayoutMediator = new TabLayoutMediator(contentMenu, pager, true, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                tab.setText(getMenuTitle(position));
            }
        });
        tabLayoutMediator.attach();
     }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.calendar_navigation_menu, menu);
        return true;
    }

    public void changeAdapter(String toDay, int pagerCurrentItem){
        doPageAdapter(toDay, pagerCurrentItem);
    }

    private void doPageAdapter(String toDay, int pagerCurrentItem){
        pageAdapter = new  ContentPages(this, project, line, toDay, this);
        pager.setAdapter(pageAdapter);
        pager.setCurrentItem(pagerCurrentItem);
    }

    private String getMenuTitle(int position) {
        type = pageAdapter.getContentType(position);
        int res;
        switch (type) {
            case IMAGE:
                res = R.string.menu_IMAGE;
                break;
            case VIDEO:
                res = R.string.menu_VIDEO;
                break;
            case PANORAMA:
                res = R.string.menu_PANORAMA;
                break;
            case AERIAL:
                res = R.string.menu_AERIAL;
                break;
            case TIMELAPSE:
                res = R.string.menu_TIMELAPSE;
                break;

            default:
                res = R.string.menu_UNK;
                break;
        }

        return getString(res);
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);
        bar.setTitle(line.getName());
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.calendar) {
            onClickCalendar(toolbar);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    void goCalendar(){
        int currentItem = pager.getCurrentItem();
        if(pageAdapter.getTabs().size() < 1 ){
            return;
        }
        Router.showCalendar(this, line, currentItem, pageAdapter.getContentType(currentItem), pageAdapter.getDayWithContent());
    }

    public void onClickCalendar(View view){ goCalendar(); }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (data == null) {
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
        doPageAdapter(data.getStringExtra("day"), data.getIntExtra("pagerCurrentItem", 0));
    }
}
