package com.doosinc.platforma.router;

import android.app.Activity;
import android.content.Intent;

import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.pages.CalendarPage;
import com.doosinc.platforma.pages.ContentsPage;
import com.doosinc.platforma.pages.LinesPage;
import com.doosinc.platforma.pages.MainPage;
import com.doosinc.platforma.pages.LoginPage;
import com.doosinc.platforma.pages.RegistrationPage;
import com.doosinc.platforma.pages.SelectedImageContentPage;
import com.doosinc.platforma.pages.SelectedVideoCompanyContentPage;
import com.doosinc.platforma.pages.SelectedVideoContentPage;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class Router {

    static public void checkAuth(Activity activity) {
        User user = new User(activity);

        Intent intent;
        if (user.getAuthenticated()) {
            intent = new Intent(activity, MainPage.class);
        } else {
            intent = new Intent(activity, LoginPage.class);
        }

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivity(intent);
        activity.finish();
    }

    static public void logout(Activity activity) {
        User user = new User(activity);
        user.logout();
        Router.checkAuth(activity);
    }

    static public void registerUser(Activity activity){
       Intent intent = new Intent(activity, RegistrationPage.class);
       activity.startActivity(intent);
    }

    static public void showLines(Activity activity, Project project) {
        Intent intent = new Intent(activity, LinesPage.class);
        intent.putExtra(Project.class.getSimpleName(), project);
        activity.startActivity(intent);
    }

    static public void showContents(Activity activity,
                                     Project project,
                                     Line line,
                                     String dayContent) {
        Intent intent = new Intent(activity, ContentsPage.class);
        intent.putExtra(Project.class.getSimpleName(), project);
        intent.putExtra(Line.class.getSimpleName(), line);
        intent.putExtra("day", dayContent);
        activity.startActivity(intent);

    }

    static public void showContentsNearDate(Activity activity,
                                            Project project,
                                            Line line,
                                            String dayContent,
                                            int pagerCurrentItem) {
        Intent intent = new Intent(activity, ContentsPage.class);
        intent.putExtra(Project.class.getSimpleName(), project);
        intent.putExtra(Line.class.getSimpleName(), line);
        intent.putExtra("day", dayContent);
        intent.putExtra("pagerCurrentItem",pagerCurrentItem);
        activity.startActivity(intent);
        activity.finish();
    }

    static public void showImageContent(Activity activity,
                                        Line line,
                                        Integer selectedIndex,
                                        ArrayList<ContentParcelable> contents) {
        Intent intent = new Intent(activity, SelectedImageContentPage.class);
        intent.putExtra(Line.class.getSimpleName(), line);
        intent.putExtra("selectedIndex", selectedIndex);
        intent.putExtra("contents", contents);
        activity.startActivity(intent);
    }

    static public void showVideoContent(Activity activity,
                                        Line line,
                                        Integer selectedIndex,
                                        ArrayList<ContentParcelable> contents) {
        Intent intent = new Intent(activity, SelectedVideoContentPage.class);
        intent.putExtra(Line.class.getSimpleName(), line);
        intent.putExtra("selectedIndex", selectedIndex);
        intent.putExtra("contents", contents);
        activity.startActivity(intent);
    }

    static public void showStreamContent(Activity activity,
                                         Integer selectedIndex,
                                         ArrayList<CompanyContentParcelable> contents,
                                         Company company) {
        Intent intent = new Intent(activity, SelectedVideoCompanyContentPage.class);
        intent.putExtra(Company.class.getSimpleName(), company);
        intent.putExtra("selectedIndex", selectedIndex);
        intent.putExtra("contents", contents);
        activity.startActivity(intent);
    }

    static public void showCalendar( Activity activity,
                                     Line line,
                                     int pagerCurrentItem,
                                     Content.ContentType typeContent,
                                     String relevantDate) {
        Intent intent = new Intent(activity, CalendarPage.class);
        intent.putExtra(Line.class.getSimpleName(), line);
        intent.putExtra("pagerCurrentItem", pagerCurrentItem);
        intent.putExtra("typeContent", typeContent );
        intent.putExtra("relevantDate", relevantDate);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivityForResult(intent, 0);
    }

    static public void showDayContent(Activity activity,
                                      String dayWithContent,
                                      int pagerCurrentItem){
        Intent intent = new Intent();
        intent.putExtra("day", dayWithContent);
        intent.putExtra("pagerCurrentItem", pagerCurrentItem);
        activity.setResult(RESULT_OK, intent);
        activity.finish();
    }
}
