package com.doosinc.platforma.pages.fragments;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toolbar;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.PromoPages;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.models.PromoFilter;
import com.doosinc.platforma.pages.MainPage;
import com.doosinc.platforma.tools.ApiError;
import com.doosinc.platforma.tools.Month;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import java.util.ArrayList;
import java.util.HashMap;

public class PromoFragment extends Fragment {

    private ContentLoadingProgressBar progressBar;
    private Company company;
    private ViewPager2 pager;
    private TabLayout promoMenu;
    private Toolbar toolbar;
    private ArrayList<PromoFilter> promoFilters;
    private HashMap<String, Integer> hashMap = new HashMap<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        setHasOptionsMenu(true);

        View rootView = inflater.inflate(R.layout.promo_fragment, container, false);

        progressBar = rootView.findViewById(R.id.progressBar);

        MainPage mainPage = (MainPage) getActivity();
        if (mainPage != null) {

            company = mainPage.company;
        }

        pager = rootView.findViewById(R.id.promoPages);
        promoMenu = rootView.findViewById(R.id.promoMenu);
        toolbar = rootView.findViewById(R.id.toolbar);

        getSectionsPromo();
        return rootView;
    }

    private void getSectionsPromo(){
        //noinspection Convert2Lambda
        new Api(getContext()).getPromoFilter(company.getId(), new Api.ApiResult<ArrayList<PromoFilter>>() {
            @Override
            public void completion(Error error, ArrayList<PromoFilter> data) {
                Activity activity = getActivity();
                if (activity == null) {
                    return;
                }
                //noinspection Convert2Lambda
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, getActivity());
                        } else {
                            doPromoFilter(data);
                        }
                    }
                });

            }
        });
    }

    private void doPromoFilter(ArrayList<PromoFilter> data){
        if ( data == null ) {
            return;
        }

        promoFilters = data;
        PromoPages pageAdapter = new PromoPages(this, data);
        pager.setAdapter(pageAdapter);

        @SuppressWarnings("Convert2Lambda")
        TabLayoutMediator tabLayoutMediator = new TabLayoutMediator(promoMenu, pager, true, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                tab.setText(data.get(position).getTitle());
            }
        });
        tabLayoutMediator.attach();
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.calendar) {
            onClickCalendar(toolbar);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void onClickCalendar(View view){

        countContentByMonth();

    }

    private void countContentByMonth(){

        for(PromoFilter filter : promoFilters) {

            getContent(filter.getId());
        }

    }

    private void getContent(String promoFilterId){

        HashMap<String, String> parameters = new HashMap<>();
        parameters.put("filterId[]", promoFilterId);

        //noinspection Convert2Lambda
        new Api(getContext()).getPromoContent(company.getId(),parameters, new Api.ApiResult<ArrayList<CompanyContent>>() {
            @Override
            public void completion(final Error error, ArrayList<CompanyContent> data) {

                Activity activity = getActivity();
                if (activity == null) {
                    return;
                }
                //noinspection Convert2Lambda
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, getActivity());
                        } else {
                            sortingContent(data);
                        }
                    }
                });

            }
        });
    }

    private void sortingContent( ArrayList<CompanyContent> contents){

        for(CompanyContent content : contents) {

            Month month = new Month();
            String key = month.getHashMap().get(content.getDate().substring(5,7)) + " " + content.getDate().substring(0,4);
            Log.d("DINC",  "" + key );

            Integer count = hashMap.get(key);
            if(count == null){
                hashMap.put(key, 1);
            }else {
                hashMap.remove(key);
                hashMap.put(key, count + 1);
            }
        }

        for (HashMap.Entry entry : hashMap.entrySet()) {

            Log.d("DINC",  "Key: " + entry.getKey() + " Value: " + entry.getValue() );
        }

    }
}



