package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.models.ContentSrc;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CompanyContentParser {

    public static ArrayList<CompanyContent> parseList(JSONArray jsonArray, CompanyContent.TypeSection typeSection) {
        ArrayList<CompanyContent> contents = new ArrayList<>();
        if (jsonArray == null) {
            return contents;
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            CompanyContent content = new CompanyContent();
            content.setTypeSection(typeSection);
            content.setId(json.optInt("id"));
            content.setDescription(json.optString("description"));
            content.setDate(json.optString("date"));

            ContentSrc image = ContentSrcParser.parse(json.optJSONObject("src"));
            content.setImage(image);

            CompanyContent.ContentType type = CompanyContent.ContentType.getType(json.optString("type"));
            content.setType(type);

            contents.add(content);
        }

        return contents;
    }
}
