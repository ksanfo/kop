package com.doosinc.platforma.tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;


public class DateConversion {

        public String formatDateA(String dateParameter) {
            if(dateParameter == null){
                return ("00/00/0000");
            }
            Date date;
            SimpleDateFormat dateFormatIn = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
            dateFormatIn.setLenient(true);
            try {
                date = dateFormatIn.parse(dateParameter);
            }catch (ParseException e){
                return ("00/00/0000");
            }
            SimpleDateFormat dateFormatOut = new SimpleDateFormat("dd/mm/yyyy", Locale.ENGLISH);

            return dateFormatOut.format(date != null ? date : "00/00/0000");
        }

        public GregorianCalendar doGregorianCalendar(String dateParameter){

            GregorianCalendar calendar = new GregorianCalendar();

            if(dateParameter == null){
                return calendar;
            }

            Date day = new Date(0);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            try {
                day= format.parse(dateParameter);
            } catch (ParseException e) {
                e.printStackTrace();
                calendar.setTime(day);
            }
            calendar.setTime(day != null ? day : new Date(0));
            return calendar;
        }

        public String doStringFromDate(Date day){
            SimpleDateFormat dateFormatOut = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            return dateFormatOut.format(day != null ? day : "0000-00-00");
        }

        public String doStingFromGregorianCalendar(GregorianCalendar date){

            if(date == null){
                return ("00.00.0000");
            }

            Integer monthInt = date.get(GregorianCalendar.MONTH) + 1;
            Integer dayInt = date.get(GregorianCalendar.DAY_OF_MONTH);
            String month;
            String day;

            String year = String.valueOf(date.get(GregorianCalendar.YEAR));

            if (monthInt < 10 ){
                month = "0" + monthInt;
            }else{ month = String.valueOf(monthInt); }

            if (dayInt < 10 ){
                day = "0" + dayInt;
            }else{ day = String.valueOf(dayInt); }

            return day + "." + month + "." + year;
        }

        public String doStingFromGregorianCalendarDash(GregorianCalendar date){

        if(date == null){
            return ("0000-00-00");
        }

        Integer monthInt = date.get(GregorianCalendar.MONTH) + 1;
        Integer dayInt = date.get(GregorianCalendar.DAY_OF_MONTH);
        String month;
        String day;

        String year = String.valueOf(date.get(GregorianCalendar.YEAR));

        if (monthInt < 10 ){
            month = "0" + monthInt;
        }else{ month = String.valueOf(monthInt); }

        if (dayInt < 10 ){
            day = "0" + dayInt;
        }else{ day = String.valueOf(dayInt); }

        return year + "-" + month + "-" + day;
    }

        public String formatDateB(String dateParameter) {
            if(dateParameter == null){
                return ("0000-00-00");
            }
            Date date;
            SimpleDateFormat dateFormatIn = new SimpleDateFormat("dd.mm.yyyy", Locale.ENGLISH);
            dateFormatIn.setLenient(true);
            try {
                date = dateFormatIn.parse(dateParameter);
            }catch (ParseException e){
                return ("0000-00-00");
            }
            SimpleDateFormat dateFormatOut = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);

            return dateFormatOut.format(date != null ? date : "0000-00-00");
        }
}
