package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.DayWithContent;
import com.doosinc.platforma.tools.DateConversion;

import org.json.JSONArray;

import java.util.ArrayList;

public class DayWithContentParser {
    public static ArrayList<DayWithContent> parseList(JSONArray jsonArray) {

        ArrayList<DayWithContent> dayWithContentArrayList = new ArrayList<>();

        if (jsonArray == null) {
            return dayWithContentArrayList;
        }

        for (int i = 0; i < jsonArray.length(); i++) {

            DayWithContent dayWithContent = new DayWithContent();
            dayWithContent.setDay(new DateConversion().doGregorianCalendar(jsonArray.optString(i)));
            dayWithContentArrayList.add(dayWithContent);
        }
        return dayWithContentArrayList;
    }
}
