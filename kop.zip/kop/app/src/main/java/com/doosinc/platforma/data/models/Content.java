package com.doosinc.platforma.data.models;

public class Content {
    public enum ContentType {
        IMAGE("IMAGE"),
        VIDEO("VIDEO"),
        PANORAMA("PANORAMA"),
        AERIAL("AERIAL"),
        TIMELAPSE("TIMELAPSE"),
        AEROPANORAMA("AEROPANORAMA"),
        UNK("UNK");

        private String type;

        ContentType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        static public ContentType getType(String type) {
            try {
                return valueOf(type);
            } catch (IllegalArgumentException e) {
                return UNK;
            }
        }
    }

    private Integer id;
    private String descr;
    private ContentSrc image;
    private ContentType type;
    private String date;

    public void setDate(String date) { this.date = date; }

    public String getDate() { return date; }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public ContentSrc getImage() {
        return image;
    }

    public void setImage(ContentSrc image) {
        this.image = image;
    }

    public ContentType getType() {
        return type;
    }

    public void setType(ContentType type) {
        this.type = type;
    }
}
