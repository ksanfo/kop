package com.doosinc.platforma.data.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Company implements Serializable {
    public enum ContentType {
        STREAM("STREAM"),
        PROMO("PROMO"),
        UNK("UNK");

        private String type;

        ContentType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        static public ContentType getType(String type) {
            try {
                return valueOf(type);
            } catch (IllegalArgumentException e) {
                return UNK;
            }
        }
    }

    private Integer id;
    private String name;
    private ContentType[] contents;
    private ArrayList<Project> projects;
    private ContentSrc image;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ContentType[] getContents() {
        return contents;
    }

    public void setContents(ContentType[] contents) {
        this.contents = contents;
    }

    public ArrayList<Project> getProjects() {
        return projects;
    }

    public void setProjects(ArrayList<Project> projects) {
        this.projects = projects;
    }

    public ContentSrc getImage() {
        return image;
    }

    public void setImage(ContentSrc image) {
        this.image = image;
    }
}
