package com.doosinc.platforma.bindingAdapters;

import android.view.View;

import androidx.databinding.BindingAdapter;

public class CommonsBindingAdapter {
    @BindingAdapter({"common_hide_is_null"})
    public static void commonHideIsNull(View view, Object value) {
        int visibility;
        if (value == null) {
            visibility = View.INVISIBLE;
        } else {
            visibility = View.VISIBLE;
        }
        view.setVisibility(visibility);
    }
}
