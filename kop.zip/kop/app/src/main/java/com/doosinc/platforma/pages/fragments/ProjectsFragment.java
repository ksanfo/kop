package com.doosinc.platforma.pages.fragments;


import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.doosinc.platforma.adapters.ProjectsList;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.R;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;

import java.util.ArrayList;


public class ProjectsFragment extends Fragment {

    private User user;
    private ArrayList<Project> projects = new ArrayList<>();
    private ProjectsList adapter;
    private ContentLoadingProgressBar progressBar;
    private ProjectHandler handler = new ProjectHandler();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView =
                inflater.inflate(R.layout.projects_fragment, container, false);

        progressBar = rootView.findViewById(R.id.projects_progress_bar);

        user = new User(getContext());
        adapter = new ProjectsList( projects, handler );

        RecyclerView recyclerView = rootView.findViewById(R.id.project_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        projectsOperation();

        return rootView;
    }


    private void projectsOperation() {

        //noinspection Convert2Lambda
        new Api(getContext()).getProjects(user.getCompanyId(), new Api.ApiResult<ArrayList<Project>>() {
            @Override
            public void completion(final Error error, final ArrayList<Project> data) {

                if (getActivity() == null) return;
                //noinspection Convert2Lambda
                getActivity().runOnUiThread(
                        new Runnable() {
                            @Override
                            public void run() {
                                progressBar.hide();
                                if (error != null) {
                                    ApiError.processingErrorsConnecting(error, getActivity());
                                } else {
                                    done(data);
                                }
                            }
                        }
                );
            }
        });
    }

    private void done(ArrayList<Project> projects) {

        if ( projects == null ) {
            return;
        }

        this.projects.clear();
        this.projects.addAll(projects);
        adapter.notifyDataSetChanged();
    }


    public class ProjectHandler{

        public void ProjectSelect( Project project){
            Router.showLines( getActivity(), project );
        }
    }

}
