package com.doosinc.platforma.api.classes;

public class Error {
    public enum CodeType {
        API,
        AUTH,
        OTHER
    }

    private CodeType code;
    private String message;

    public Error(CodeType code, String message) {
        this.code = code;
        this.message = message;
    }

    public CodeType getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
