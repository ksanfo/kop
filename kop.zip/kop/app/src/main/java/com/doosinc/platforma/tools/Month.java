package com.doosinc.platforma.tools;

import java.util.HashMap;

public class Month {

    private HashMap<String, String> hashMap = new HashMap<>();

    public Month() {
        hashMap.put("01", "Январь");
        hashMap.put("02", "Февраль");
        hashMap.put("03", "Март");
        hashMap.put("04", "Апрель");
        hashMap.put("05", "Май");
        hashMap.put("06", "Июнь");
        hashMap.put("07", "Июль");
        hashMap.put("08", "Август");
        hashMap.put("09", "Сентябрь");
        hashMap.put("10", "Октябрь");
        hashMap.put("11", "Ноябрь");
        hashMap.put("12", "Декабрь");
    }

    public HashMap<String, String> getHashMap() {
        return hashMap;
    }
}
