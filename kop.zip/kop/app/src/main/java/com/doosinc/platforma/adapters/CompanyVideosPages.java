package com.doosinc.platforma.adapters;

import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;
import com.doosinc.platforma.databinding.CompanyVideoPageCellBinding;


import java.util.ArrayList;

public class CompanyVideosPages extends RecyclerView.Adapter<CompanyVideosPages.ViewHolder> {
    private ArrayList<CompanyContentParcelable> contents;
    private Listener listener;

    public CompanyVideosPages(ArrayList<CompanyContentParcelable> contents) {
        this.contents = contents;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    @Override
    public int getItemCount() {
        if (contents == null) {
            return 0;
        }

        return contents.size();
    }

    @NonNull
    public CompanyVideosPages.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        CompanyVideoPageCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.company_video_page_cell, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CompanyVideosPages.ViewHolder holder, final int position) {
        CompanyContentParcelable content = contents.get(position);

        CompanyContent.TypeSection typeSection = content.getTypeSection();
        if (typeSection == CompanyContent.TypeSection.PROMO) {
            holder.binding.player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (listener != null) {
                        listener.videoFinished(position);
                    }
                }
            });
        } else {
            holder.binding.player.setLooping(true);
        }

        holder.binding.setContent(content);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CompanyVideoPageCellBinding binding;

        ViewHolder(CompanyVideoPageCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface Listener {
        void videoFinished(int position);
    }
}
