package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.tools.DateConversion;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ContentParser {
    public static ArrayList<Content> parseList(JSONArray jsonArray) {
        ArrayList<Content> contents = new ArrayList<>();

        if (jsonArray == null) {
            return contents;
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            Content content = new Content();
            content.setId(json.optInt("id"));
            content.setDescr(json.optString("description"));
            content.setDate(new DateConversion().formatDateA(json.optString("date")));

            ContentSrc image = ContentSrcParser.parse(json.optJSONObject("src"));
            content.setImage(image);

            Content.ContentType type = Content.ContentType.getType(json.optString("type"));
            content.setType(type);

            contents.add(content);
        }


        return contents;
    }
}
