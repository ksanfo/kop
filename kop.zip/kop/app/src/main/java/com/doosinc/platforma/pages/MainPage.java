package com.doosinc.platforma.pages;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.R;

import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.pages.fragments.AccountFragment;
import com.doosinc.platforma.pages.fragments.ProjectsFragment;
import com.doosinc.platforma.pages.fragments.PromoFragment;
import com.doosinc.platforma.pages.fragments.StreamFragment;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.CompanyTools;
import com.doosinc.platforma.tools.ApiError;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.ArrayList;

public class MainPage extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    User user;
    Toolbar toolbar;
    public Company company;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        toolbar = findViewById(R.id.toolbar);
        initActionBar();

        user = new User(this);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(
                this::menuSwitch);
        bottomNavigationView.setVisibility(View.GONE);

        mainOperation();
    }

    void mainOperation() {

        final ContentLoadingProgressBar progressBar = findViewById(R.id.progress_bar);
        toolbar.setTitle(getString(R.string.loading));

        new Api(this).getCompanies((error, data) -> runOnUiThread(
                () -> {
                    progressBar.hide();
                    if (error != null) {
                        ApiError.processingErrorsConnecting(error, MainPage.this);
                        toolbar.setTitle(getString(R.string.noLoading));
                    } else {
                        done(data);
                    }
                }
        ));
    }

    void done( ArrayList<Company> companies ) {
        if (companies.isEmpty()) {
            return;
        }

        Integer companyId = CompanyTools.getCompanyId(user.getCompanyId(), companies);
        user.setCompanyId(companyId);
        user.save();
        company = CompanyTools.getCompanyById(companyId, companies);
        if (company == null) {
            return;
        }

        showMenu(company.getContents());

        toolbar.setTitle(company.getName());
    }

    void showMenu(Company.ContentType[] types) {
        for (Company.ContentType type : types) {
            if (type == Company.ContentType.STREAM) {
                menuChangeItemStream();
            } else if (type == Company.ContentType.PROMO) {
                menuChangeItemPromo();
            }
        }

        bottomNavigationView.setVisibility(View.VISIBLE);
        bottomNavigationView.setSelectedItemId(R.id.projects);
    }

    boolean menuSwitch(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.projects:
                onProjects();
                return true;
            case R.id.promo:
                onPromo();
                return true;
            case R.id.account:
                onAccount();
                return true;
            case R.id.stream:
                onStream();
                return true;
        }

        return false;
    }

    void onProjects() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.frame, new ProjectsFragment());
        transaction.commitAllowingStateLoss();
    }
    void onPromo() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.frame, new PromoFragment());
        transaction.commitAllowingStateLoss();
    }

    void onAccount() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.frame, new AccountFragment());
        transaction.commitAllowingStateLoss();
    }

    void onStream() {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.frame, new StreamFragment());
        transaction.commitAllowingStateLoss();
    }


    void menuChangeItemStream() {
        Menu menu = bottomNavigationView.getMenu();
        menu.findItem(R.id.stream).setVisible(true);
    }

    void menuChangeItemPromo() {
        Menu menu = bottomNavigationView.getMenu();
        menu.findItem(R.id.promo).setVisible(true);
    }



    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        Router.checkAuth(MainPage.this);
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.calendar_navigation_menu, menu);
        return false;
    }
}
