package com.doosinc.platforma.bindingAdapters;

import android.graphics.drawable.Drawable;

import android.widget.ImageView;

import androidx.databinding.BindingAdapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.tools.GlideTools;

public class ImageBindingAdapter {
    @BindingAdapter(value = {"image_src", "image_placeholder"})
    public static void loadImageSrc(ImageView view, ContentSrc image, Drawable drawable) {
        if (image == null) {
            view.setImageDrawable(drawable);
            return;
        }
        ImageBindingAdapter.loadImage(view, image.getSrc(), drawable);
    }

    @BindingAdapter(value = {"image_tmb", "image_placeholder"})
    public static void loadImageTmb(ImageView view, ContentSrc image, Drawable drawable) {
        if (image == null) {
            view.setImageDrawable(drawable);
            return;
        }
        ImageBindingAdapter.loadImage(view, image.getTmb(), drawable);
    }

    @BindingAdapter(value = {"image_url", "image_placeholder"})
    public static void loadImageUrl(ImageView view, String url, Drawable drawable) {
        if (url == null) {
            view.setImageDrawable(drawable);
            return;
        }
        ImageBindingAdapter.loadImage(view, url, drawable);
    }

    private static void loadImage(final ImageView view, String url, Drawable resourceId) {
        if (url == null || url.length() == 0) {
            view.setImageDrawable(resourceId);
            return;
        }

        GlideUrl glideUrl = GlideTools.getUrl(view.getContext(), url);

        Glide.with(view.getContext())
                .load(glideUrl)
                .placeholder(resourceId)
                .into(view);
    }
}
