package com.doosinc.platforma.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import java.util.Map;

public class Setups {
    private SharedPreferences preferences;

    public Setups(Context context) {
        preferences = context.getSharedPreferences("setups", Context.MODE_PRIVATE);
    }

    public void saveStr(String key, String value) {
        Editor editor = getEditor();
        editor.putString(key, value);
        editor.commit();
    }

    public String getStr(String key) {
        return preferences.getString(key, "");
    }

    public void saveBool(String key, Boolean value) {
        Editor editor = getEditor();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public Boolean getBool(String key) {
        return preferences.getBoolean(key, false);
    }

    public Integer getInt(String key, Integer def) {
        Integer out = def;
        try {
            return preferences.getInt(key, def);
        } catch (Throwable t) {
            String value = getStr(key);
            if (value != null && value.length() > 0) {
                try {
                    out = Integer.valueOf(value);
                } catch (NumberFormatException e) {
                    out = def;
                }

            }
        }

        return out;
    }

    public void saveInt(String key, int value) {
        Editor editor = getEditor();
        editor.putInt(key, value);
        editor.commit();
    }

    public Float getFloat(String key, Float def) {
        Float out = def;

        try {
            out = preferences.getFloat(key, def);
        } catch (Throwable t) {
            String value = getStr(key);
            if (value != null && value.length() > 0) {
                try {
                    out = Float.parseFloat(value);
                } catch (NumberFormatException e) {
                    out = def;
                }

            }
        }

        return out;
    }

    public void saveFloat(String key, float value) {
        Editor editor = getEditor();
        editor.putFloat(key, value);
        editor.commit();
    }

    public void unset(String key) {
        Editor editor = getEditor();
        editor.remove(key);
        editor.commit();
    }

    public void removeAll() {
        Editor editor = getEditor();
        Map<String,?> keys = preferences.getAll();
        for(Map.Entry<String,?> entry : keys.entrySet()) {
            editor.remove(entry.getKey());
        }

        editor.commit();
    }

    private Editor getEditor() {
        return preferences.edit();
    }
}
