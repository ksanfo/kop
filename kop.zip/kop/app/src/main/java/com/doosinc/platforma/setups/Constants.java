package com.doosinc.platforma.setups;

public class Constants {
    public static String siteUrl = "https://platforma.tech";
    public static String apiURL = siteUrl + "/user/api/";
}
