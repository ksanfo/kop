package com.doosinc.platforma.tools;

import android.content.Context;
import android.graphics.Typeface;
import android.util.Log;

import java.util.HashMap;

public class FontHelper {
    private static final HashMap<String, Typeface> cache = new HashMap<>();

    public static Typeface getFont(Context context, String fontName) {
        if (fontName == null) {
            return null;
        }
        String fontPath = "fonts/" + fontName;

        Typeface font = cache.get(fontPath);
        if (font == null) {
            try {
                font = Typeface.createFromAsset(context.getAssets(), fontPath);
                cache.put(fontPath, font);
            } catch (Exception e) {
                Log.d("DINC", "font " + fontPath + " " + e.getLocalizedMessage());
            }

        }

        return font;
    }
}
