package com.doosinc.platforma.api.modelParsers;

import android.content.Context;

import com.doosinc.platforma.data.models.User;

import org.json.JSONObject;

public class UserParser {

    static public User parse(JSONObject userJson, Context context) {
        User user = new User(context);
        user.setId(userJson.optInt("id"));
        user.setName(userJson.optString("name"));
        user.setLogin(userJson.optString("email"));
        user.setCanCreateTmpUser(userJson.optBoolean("canCreateTmpUser"));
        return user;
    }
}
