package com.doosinc.platforma.pages;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.LinesList;

import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;

import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;

import java.util.ArrayList;


public class LinesPage extends AppCompatActivity {
    Project project;
    Toolbar toolbar;
    private ArrayList<Line> lines = new ArrayList<>();
    private LinesList adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lines_page);

        toolbar = findViewById(R.id.toolbar);
        initActionBar();

        Bundle argument = getIntent().getExtras();
        if (argument == null) {
            return;
        } else {
            project = (Project) argument.getSerializable(Project.class.getSimpleName());
        }

        adapter = new LinesList(lines, new LineHandler());

        RecyclerView recyclerView = findViewById(R.id.line_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        linesOperation();
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    void linesOperation() {
        final ContentLoadingProgressBar progressBar = findViewById(R.id.progress_bar);
        toolbar.setTitle(getString(R.string.loading));

        //noinspection Convert2Lambda
        new Api(this).getLines(project.getId(), new Api.ApiResult<ArrayList<Line>>() {
            @Override
            public void completion(final Error error, final ArrayList<Line> data) {
                //noinspection Convert2Lambda
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, LinesPage.this);
                        } else {
                            done(data);
                        }
                    }
                });

            }
        });

    }

    void done(ArrayList<Line> lines) {
        if (lines == null) {
            return;
        }

        this.lines.clear();
        this.lines.addAll(lines);
        adapter.notifyDataSetChanged();
        toolbar.setTitle(project.getName());
    }

    public class LineHandler {
        public void lineSelect(Line line) {
           Router.showContents(LinesPage.this, project, line, null);
        }
    }
}
