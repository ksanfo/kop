package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.setups.Constants;

import org.json.JSONObject;

class ContentSrcParser {
    static ContentSrc parse(JSONObject json) {
        ContentSrc contentSrc = new ContentSrc();
        if (json == null) {
            return contentSrc;
        }

        String srcStr = json.optString("src");
        String src = ContentSrcParser.url(srcStr);
        if (src != null) {
            contentSrc.setSrc(src);
        }

        String tmbStr = json.optString("tmb");
        String tmb = ContentSrcParser.url(tmbStr);
        if (tmb != null) {
            contentSrc.setTmb(tmb);
        }

        return contentSrc;
    }

    private static String url(String src) {
        if (src == null) {
            return null;
        }

        if (src.startsWith("http")) {
            return src;
        }

        return Constants.siteUrl + src;
    }
}
