package com.doosinc.platforma.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.doosinc.platforma.R;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.databinding.ImagePageCellBinding;
import com.doosinc.platforma.tools.GlideTools;
import com.ortiz.touchview.TouchImageView;

import java.util.ArrayList;

public class ImagesPages extends RecyclerView.Adapter<ImagesPages.ViewHolder> {
    private ArrayList<ContentParcelable> contents;
    private int selectedIndex;

    public ImagesPages(ArrayList<ContentParcelable> contents, int selectedIndex) {
        this.contents = contents;
        this.selectedIndex = selectedIndex;
    }

    public int getItemCount() {
        if (contents == null) {
            return 0;
        }

        return contents.size();
    }

    @NonNull
    public ImagesPages.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ImagePageCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.image_page_cell, parent, false);
        return new ViewHolder(binding);
    }

    @SuppressLint("ClickableViewAccessibility")
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ContentParcelable content = contents.get(position);
        holder.binding.setContent(content);

        final TouchImageView imageView = holder.binding.image;

        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                boolean result = true;
                if (event.getPointerCount() >= 2 || imageView.canScrollHorizontally(1) && imageView.canScrollHorizontally(-1)) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            imageView.getParent().requestDisallowInterceptTouchEvent(true);
                            result = false;
                            break;

                        case MotionEvent.ACTION_MOVE:
                            imageView.getParent().requestDisallowInterceptTouchEvent(true);
                            result = false;
                            break;

                        case MotionEvent.ACTION_UP:
                            imageView.getParent().requestDisallowInterceptTouchEvent(false);
                            result = true;
                            break;

                        default: result = true;
                        break;
                    }

                }
                return result;
            }
        });

        if (selectedIndex == position) {
            selectedIndex = -1;
            loadTmbImage(imageView, content);
        } else {
            loadSrcImage(imageView, content, true);
        }
    }

    private void loadTmbImage(final TouchImageView imageView, final ContentParcelable content) {
        Context context = imageView.getContext();
        String url = content.getTmb();

        GlideUrl glideUrl = GlideTools.getUrl(context, url);
        Glide.with(context)
                .load(glideUrl)
                .into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        imageView.setImageDrawable(resource.getCurrent());
                        loadSrcImage(imageView, content, false);
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }

    private void loadSrcImage(final TouchImageView imageView,
                              final ContentParcelable content,
                              boolean withPlaceholder) {
        Context context = imageView.getContext();
        String url = content.getSrc();

        GlideUrl glideUrl = GlideTools.getUrl(context, url);

        if (withPlaceholder) {
            imageView.setImageResource(R.drawable.dummy);
        }

        Glide.with(context)
                .load(glideUrl)
                .into(new CustomTarget<Drawable>() {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        imageView.setImageDrawable(resource.getCurrent());
                    }

                    @Override
                    public void onLoadCleared(@Nullable Drawable placeholder) {
                    }
                });
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImagePageCellBinding binding;

        ViewHolder(ImagePageCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}
