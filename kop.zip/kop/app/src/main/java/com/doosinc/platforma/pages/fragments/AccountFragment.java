package com.doosinc.platforma.pages.fragments;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.doosinc.platforma.R;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Company;

import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.databinding.AccountFragmentBinding;

import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;
import com.doosinc.platforma.tools.CompanyTools;

import java.util.ArrayList;


public class AccountFragment extends Fragment {

    public User user;
    private AccountFragmentBinding binding;
    private ArrayList<Company> companies;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        user = new User(getContext());
        binding = DataBindingUtil.inflate(inflater, R.layout.account_fragment, container, false);
        binding.setHandlerAccount(new AccountHandler());
        binding.setUser(user);
        binding.setButtonChangeCompany(false);

        accountOperation();
        return binding.getRoot();
    }

    private void accountOperation() {
        binding.setLoadingCompany(true);
        //noinspection Convert2Lambda
        new Api(getActivity()).getCompanies(new Api.ApiResult<ArrayList<Company>>() {
            @Override
            public void completion(final Error error, final ArrayList<Company> data) {
                if (getActivity() == null) return;
                //noinspection Convert2Lambda
                getActivity().runOnUiThread(
                        new Runnable() {
                            @Override
                            public void run() {
                                binding.setLoadingCompany(false);
                                if (error != null) {
                                    ApiError.processingErrorsConnecting(error, getActivity());
                                } else {
                                    done(data);
                                }
                            }
                        }
                );


            }
        });
    }

    private void done(ArrayList<Company> companies) {
        this.companies = companies;
        if (companies.isEmpty()) {
            return;
        }
        Integer companyId = CompanyTools.getCompanyId(user.getCompanyId(), companies);
        Company company = CompanyTools.getCompanyById(companyId, companies);
        binding.setCompany(company);
        visualButtonChangeCompany();
    }

    private void visualButtonChangeCompany(){

        if(companies.size() > 1){
            binding.setButtonChangeCompany(true);
        }
    }

    public class AccountHandler {

        public void goOut() {

            if (getContext() == null) {
                return;
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(getContext(), R.style.AlertDialogStyle);
            builder.setTitle(R.string.pre_out);
            builder.setCancelable(true);
            //noinspection Convert2Lambda
            builder.setPositiveButton(R.string.ok,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Router.logout(getActivity());
                        }
                    });
            //noinspection Convert2Lambda
            builder.setNegativeButton(R.string.no,
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }

        public void changeCompany() {

            if(getActivity()==null){
                return;
            }
            int countCompany = companies.size();

            if(countCompany < 2){
                return;
            }

            int userCompanyId = user.getCompanyId();
            int indexCompanySelect = 0;
            final int[] idCompanySelect = new int[countCompany - 1];
            String[] nameCompanySelect = new String[countCompany - 1];

            for (int i = 0; i < companies.size(); i++) {

                if(companies.get(i).getId().equals(userCompanyId)){
                    continue;
                }
                nameCompanySelect[indexCompanySelect] = companies.get(i).getName();
                idCompanySelect[indexCompanySelect] = companies.get(i).getId();
                 indexCompanySelect = indexCompanySelect + 1;
            }

            final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(   getActivity(),
                                                                            R.layout.dialog_item,
                                                                            nameCompanySelect);

            AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity(), R.style.AlertDialogStyle);
            dialog.setTitle(R.string.pre_change_company);
            //noinspection Convert2Lambda
            dialog.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int item) {
                    user.setCompanyId(idCompanySelect[item]);
                    user.save();
                    Router.checkAuth( getActivity() );
                }
            });
            AlertDialog alert = dialog.create();
            alert.show();
        }
    }
}
