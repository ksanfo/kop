package com.doosinc.platforma.data.models;

        import java.io.Serializable;

public class Project  implements Serializable {
    private Integer id;
    private String name;
    private String descr;
    private ContentSrc image;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public ContentSrc getImage() {
        return image;
    }

    public void setImage(ContentSrc image) {
        this.image = image;
    }
}
