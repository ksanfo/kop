package com.doosinc.platforma.adapters;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.pages.ContentsPage;
import com.doosinc.platforma.pages.fragments.ContentsListFragment;

import java.util.ArrayList;

public class ContentPages extends FragmentStateAdapter {
    @SuppressWarnings("FieldCanBeLocal")
    private final Content.ContentType[] tabsOrder = new Content.ContentType[]{
            Content.ContentType.AERIAL, Content.ContentType.TIMELAPSE, Content.ContentType.IMAGE, Content.ContentType.VIDEO
    };

    private Project project;
    private Line line;
    private ArrayList<Content.ContentType> tabs = new ArrayList<>();
    private String dayWithContent;
    private ContentsPage page;

    public ContentPages(@NonNull FragmentActivity fragmentActivity,
                        Project project,
                        Line line,
                        String dayWithContent,
                        ContentsPage page) {
        super(fragmentActivity);
        this.project = project;
        this.line = line;
        this.dayWithContent = dayWithContent;
        this.page = page;

        for( Content.ContentType type : tabsOrder ) {
            if (isContain(type, line.getTabs())) {
                tabs.add(type);
            }
        }
    }

    public Content.ContentType getContentType(int position) {
        return tabs.get(position);
    }

    public String getDayWithContent(){
        return dayWithContent;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Content.ContentType type = tabs.get(position);

        @SuppressWarnings("Convert2Lambda")
        Fragment fragment = new  ContentsListFragment( page, new ContentsListFragment.CurrentDate() {
            @Override
            public void change(String toDay) {
                dayWithContent = toDay;
            }
        });
        Bundle args = new Bundle();
        args.putSerializable("contentType", type);
        args.putSerializable(Project.class.getSimpleName(), project);
        args.putSerializable(Line.class.getSimpleName(), line);
        args.putString("day", dayWithContent);
        args.putInt("pagerCurrentItem", position);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public int getItemCount() {
        return tabs.size();
    }

    private boolean isContain(Content.ContentType value, Content.ContentType[] arr) {
        for (Content.ContentType type : arr) {
            if (value == type) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Content.ContentType> getTabs() {
        return tabs;
    }
}
