package com.doosinc.platforma.tools;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;

import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.R;
import com.doosinc.platforma.router.Router;

public class ApiError {

    // Обрабатываем стандартные ошибки API
    @SuppressLint("InflateParams")
    private static boolean prcErrors(Activity activity,
                                     Error error,
                                     DialogInterface.OnClickListener retryListener) {
        if (error == null) {
            return false;
        }


        Error.CodeType code = error.getCode();
        if (code == Error.CodeType.AUTH) {
            Router.logout(activity);
            return false;
        }


        if (code == Error.CodeType.API) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AlertDialogStyle);
            LayoutInflater inflater = activity.getLayoutInflater();
            //noinspection Convert2Lambda
            builder.setView(inflater.inflate(R.layout.dialog_wifi, null))
                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                            Router.checkAuth(activity);
                        }
                    });

            AlertDialog alert = builder.create();
            alert.show();

            final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.weight = 1;
            layoutParams.gravity = Gravity.CENTER;
            positiveButton.setLayoutParams(layoutParams);
            alert.setCanceledOnTouchOutside(false);
            return false;
        }

        //Other Error
        return true;
    }

    static public boolean prcErrors(Activity activity, Error error) {
        return ApiError.prcErrors(activity, error, null);
    }

    static public void processingErrorsConnecting(Error error, Activity activity) {
        if (ApiError.prcErrors(activity, error)) {
            if (error.getMessage().equals("userNotFound")) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AlertDialogStyle);
                builder.setTitle(R.string.err_auth)
                        .setNegativeButton(R.string.ok,
                                (dialog, id) -> dialog.cancel());
                AlertDialog alert = builder.create();
                alert.show();
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity, R.style.AlertDialogStyle);
                builder.setTitle(R.string.err_undef)
                        .setNegativeButton(R.string.ok,
                                (dialog, id) -> dialog.cancel());
                AlertDialog alert = builder.create();
                alert.show();
            }
        }
    }
}
