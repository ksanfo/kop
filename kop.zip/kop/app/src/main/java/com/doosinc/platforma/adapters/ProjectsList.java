package com.doosinc.platforma.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.databinding.ProjectCellBinding;
import com.doosinc.platforma.pages.fragments.ProjectsFragment;

import java.util.ArrayList;

public class ProjectsList extends RecyclerView.Adapter<ProjectsList.ViewHolder> {
    private ArrayList<Project> projects;
    private ProjectsFragment.ProjectHandler handler;

    public ProjectsList( ArrayList<Project> projects, ProjectsFragment.ProjectHandler handler ) {
        this.projects = projects;
        this.handler = handler;
    }

    public int getItemCount() {
        if (projects == null) {
            return 0;
        }
        return projects.size();
    }

    @NonNull
    public ProjectsList.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {

        LayoutInflater inflater = LayoutInflater.from( parent.getContext() );
        ProjectCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.project_cell, parent, false);
        return new ViewHolder( binding );
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.binding.setProject( projects.get(position) );
        holder.binding.setHandler( handler );
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        ProjectCellBinding binding;

        ViewHolder( ProjectCellBinding binding ) {
            super( binding.getRoot() );
            this.binding = binding;
        }
    }
}
