package com.doosinc.platforma.pages;

import android.app.Activity;

import android.content.DialogInterface;
import android.os.Bundle;

import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.doosinc.platforma.api.Api;


import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;
import com.doosinc.platforma.R;
import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.databinding.LoginBinding;

import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.databinding.DataBindingUtil;


public class LoginPage extends AppCompatActivity {
    public User user;
    public LoginHandler handler;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        user = new User(this);
        handler = new LoginHandler();
        LoginBinding binding = DataBindingUtil.setContentView(this, R.layout.login);
        binding.setUser(user);
        binding.setHandler(handler);

    }

    private void prcDone(User user) {
       user.save();
       Router.checkAuth(this);
    }

    private void loginOperation() {
        if (user.getLogin().isEmpty()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
            //noinspection Convert2Lambda
            builder.setTitle(R.string.no_login)
                    .setCancelable(false)
                    .setNegativeButton(R.string.ok,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
            AlertDialog alert = builder.create();
            alert.show();
            return;
        }

        if (user.getPassword().isEmpty()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogStyle);
            //noinspection Convert2Lambda
            builder.setTitle(R.string.no_password)
                    .setCancelable(false)
                    .setNegativeButton(R.string.ok,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
            AlertDialog alert = builder.create();
            alert.show();
            return;
        }

        final ContentLoadingProgressBar progressBar = findViewById(R.id.progress_bar);
        progressBar.setVisibility(ContentLoadingProgressBar.VISIBLE);
        //interface lock
        LoginPage.this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

        //noinspection Convert2Lambda
        new Api(this).authUser(user, this, new Api.ApiResult<User>() {
            @Override
            public void completion(final Error error, final User user) {
                //noinspection Convert2Lambda
                runOnUiThread(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setVisibility(ContentLoadingProgressBar.INVISIBLE);
                                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

                                        if (error != null) {
                                            ApiError.processingErrorsConnecting(error, LoginPage.this);
                                        }
                                         else {
                                             prcDone(user);
                                        }
                                    }
                                }
                        );
            }
        });
    }

    public class LoginHandler {

        public void comeIn() {

            //hide virtual keyboard
            InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
            }

            loginOperation();
        }

        public void toRegister() {
            Router.registerUser(LoginPage.this);
           // PreferenceManager.getDefaultSharedPreferences( LoginPage.this ).edit().clear().apply();
        }
    }
}



