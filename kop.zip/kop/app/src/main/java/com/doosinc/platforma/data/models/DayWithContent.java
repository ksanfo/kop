package com.doosinc.platforma.data.models;

import java.util.GregorianCalendar;

public class DayWithContent {

    private GregorianCalendar day;

    public void setDay(GregorianCalendar day) {
        this.day = day;
    }

    public GregorianCalendar getDay() {
        return day;
    }
}
