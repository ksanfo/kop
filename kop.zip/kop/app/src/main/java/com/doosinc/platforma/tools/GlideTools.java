package com.doosinc.platforma.tools;

import android.content.Context;

import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.doosinc.platforma.api.Api;

public class GlideTools {
    static public GlideUrl getUrl(Context context, String url) {
        String[] cookies = new Api(context).getCookieForUrl(url);
        LazyHeaders.Builder builder = new LazyHeaders.Builder();
        for (String cookie: cookies) {
            builder = builder.addHeader("Cookie", cookie);
        }

        return new GlideUrl(url, builder.build());
    }
}
