package com.doosinc.platforma.pages;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.doosinc.platforma.R;

import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.databinding.RegistrationBinding;
import com.doosinc.platforma.router.Router;

public class RegistrationPage extends AppCompatActivity {

    public User user;
    public RegisterHandler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        user = new User(this);
        handler = new RegisterHandler();

        RegistrationBinding binding = DataBindingUtil.setContentView(this, R.layout.registration);
        binding.setUser(user);
        binding.setHandler(handler);
    }

    public void onBackPressed() {
        finish();
        Router.checkAuth(this);
    }

    public class RegisterHandler{

        public void registerOperation(){
            finish();
            Router.checkAuth(RegistrationPage.this);
        }
    }
}


