package com.doosinc.platforma.pages;

import android.content.res.Configuration;
import android.os.Bundle;

import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import androidx.viewpager2.widget.ViewPager2;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.CompanyVideosPages;
import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;

import java.util.ArrayList;

public class SelectedVideoCompanyContentPage extends AppCompatActivity {

    private Toolbar toolbar;
    private ArrayList<CompanyContentParcelable> contents;
    private Integer selectedIndex;
    private Company company;
    private ViewPager2 pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        readArgument();

        setContentView(R.layout.video_contents_page);

        toolbar = findViewById(R.id.toolbar);
        initActionBar();

        pager = findViewById(R.id.contentPages);

        CompanyVideosPages pageAdapter = new CompanyVideosPages(contents);
        pager.setAdapter(pageAdapter);

        pageAdapter.setListener(new CompanyVideosPages.Listener() {
            @Override
            public void videoFinished(int position) {
                nextVideo(position);
            }
        });

        pager.setCurrentItem(selectedIndex, false);
    }

    private void nextVideo(int position) {
        position++;
        if (position >= contents.size()) {
            position = 0;
        }
        pager.setCurrentItem(position, false);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            bar.hide();
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            bar.show();
        }
    }

    private void readArgument() {
        Bundle argument = getIntent().getExtras();
        if (argument == null) {
            return;
        }
        company = (Company) argument.getSerializable(Company.class.getSimpleName());
        contents = argument.getParcelableArrayList("contents");
        selectedIndex = argument.getInt("selectedIndex");
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);

        bar.setTitle(company.getName());
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
