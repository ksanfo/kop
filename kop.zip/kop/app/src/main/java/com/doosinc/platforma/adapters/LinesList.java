package com.doosinc.platforma.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.databinding.LineCellBinding;
import com.doosinc.platforma.pages.LinesPage;

import java.util.ArrayList;

public class LinesList extends RecyclerView.Adapter<LinesList.ViewHolder> {

    private ArrayList<Line> lines;
    private LinesPage.LineHandler handler;

    public LinesList(ArrayList<Line> lines, LinesPage.LineHandler handler) {
        this.lines = lines;
        this.handler = handler;
    }

    public int getItemCount() {
        if (lines == null) {
            return 0;
        }

        double rows = Math.ceil(lines.size() / 2.0);
        return (int) rows;
    }

    @NonNull
    public LinesList.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        LineCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.line_cell, parent, false);
        return new ViewHolder(binding);
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Line[] pair = getLinesPair(position);

        holder.binding.setLineLeft(pair[0]);
        holder.binding.setLineRight(pair[1]);
    }

    private Line[] getLinesPair(int position) {
        Line[] pair = new Line[2];

        int lineIndex = position * 2;
        pair[0] = lines.get(lineIndex);

        if ((lineIndex + 1) < (lines.size())) {
            pair[1] = lines.get(lineIndex + 1);
        }

        return pair;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        LineCellBinding binding;

        ViewHolder(LineCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            binding.setHandler(handler);
        }
    }


}
