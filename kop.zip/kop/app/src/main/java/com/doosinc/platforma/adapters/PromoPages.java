package com.doosinc.platforma.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.doosinc.platforma.data.models.PromoFilter;
import com.doosinc.platforma.pages.fragments.PromoFragment;
import com.doosinc.platforma.pages.fragments.PromoTubsFragment;

import java.util.ArrayList;

public class PromoPages extends FragmentStateAdapter{

    private ArrayList<PromoFilter> promoFilter;

    public PromoPages(@NonNull  PromoFragment fragmentActivity,
                                ArrayList<PromoFilter> promoFilter) {
        super(fragmentActivity);
        this.promoFilter = promoFilter;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {

        return new PromoTubsFragment(promoFilter.get(position).getId());
    }

    @Override
    public int getItemCount() {
        return promoFilter.size();
    }
}
