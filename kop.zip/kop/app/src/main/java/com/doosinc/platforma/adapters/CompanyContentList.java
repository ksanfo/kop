package com.doosinc.platforma.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.databinding.CompanyContentsCellBinding;
import com.doosinc.platforma.databinding.ContentsCellBinding;

import java.util.ArrayList;

public class CompanyContentList extends RecyclerView.Adapter<CompanyContentList.ViewHolder> {

    private ArrayList<CompanyContentParcelable> contents;
    private CompanyContentList.Handler handler;

    public CompanyContentList(CompanyContentList.Handler handler) {
        this.handler = handler;
    }

    public void setContents(ArrayList<CompanyContentParcelable> contents) {
        this.contents = contents;
        notifyDataSetChanged();
    }

    public int getItemCount() {
        if (contents == null) {
            return 0;
        }

        double rows = Math.ceil(contents.size() / 2.0);
        return (int) rows;
    }

    @NonNull
    public CompanyContentList.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        CompanyContentsCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.company_contents_cell, parent, false);
        return new CompanyContentList.ViewHolder(binding);
    }

    public void onBindViewHolder(@NonNull CompanyContentList.ViewHolder holder, int position) {
        Integer[] indexes = getIndexes(position);
        CompanyContentParcelable[] pair = getLinesPair(indexes);
        Boolean[] shadowThumb = getShadowPair(pair);

        holder.binding.setContentLeft(pair[0]);
        holder.binding.setContentLeftIndex(indexes[0]);

        holder.binding.setContentRight(pair[1]);
        holder.binding.setContentRightIndex(indexes[1]);

        holder.binding.setHandler(handler);

        holder.binding.setShadowLeft(shadowThumb[0]);
        holder.binding.setShadowRight(shadowThumb[1]);
    }

    private Integer[] getIndexes(int position) {
        Integer[] indexes = new Integer[2];

        int lineIndex = position * 2;
        indexes[0] = lineIndex;

        if ((lineIndex + 1) < (contents.size())) {
            indexes[1] = lineIndex + 1;
        }

        return indexes;
    }

    private CompanyContentParcelable[] getLinesPair(Integer[] indexes) {
        CompanyContentParcelable[] pair = new CompanyContentParcelable[2];

        pair[0] = contents.get(indexes[0]);

        if (indexes[1] != null) {
            pair[1] = contents.get(indexes[1]);
        }

        return pair;
    }

    private Boolean[] getShadowPair(CompanyContentParcelable[] pair){

        Boolean[] shadowThumb = new Boolean[2];
        shadowThumb[0] = true;
        shadowThumb[1] = true;

        if(pair[0] != null) {
            if (pair[0].getDescr().isEmpty() || pair[0].getDescr() == null) {
                shadowThumb[0] = false;
            }
        }

        if(pair[1] != null) {
            if (pair[1].getDescr().isEmpty() || pair[1].getDescr() == null) {
                shadowThumb[1] = false;
            }
        }

        return shadowThumb;
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        CompanyContentsCellBinding binding;

        ViewHolder(CompanyContentsCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface Handler {
        void selected(Integer index);
    }
}
