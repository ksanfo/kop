package com.doosinc.platforma.data.models;

import android.content.Context;

import com.doosinc.platforma.data.Setups;

public class User {
    private Integer id;
    private String name = "";
    private String login = "";
    private String password = "";

    private Boolean isAuthenticated;
    private Integer companyId;
    private Boolean canCreateTmpUser;

    private Setups dataSetups;

    public User(Context context) {
        this.dataSetups = new Setups( context );
        load();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Boolean getAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(Boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getCanCreateTmpUser() {
        return canCreateTmpUser;
    }

    public void setCanCreateTmpUser(Boolean canCreateTmpUser) {
        this.canCreateTmpUser = canCreateTmpUser;
    }

    private void load() {
        this.id = this.dataSetups.getInt("_userId", 0);
        this.name = this.dataSetups.getStr("_userName");
        this.login = this.dataSetups.getStr("_userLogin");
        this.isAuthenticated = this.dataSetups.getBool("_userIsAuthenticated");
        this.companyId = this.dataSetups.getInt("_userCompanyId", 0);
    }

    public void save() {
        this.dataSetups.saveInt("_userId", this.id);
        this.dataSetups.saveStr("_userName", this.name);
        this.dataSetups.saveStr("_userLogin", this.login);
        this.dataSetups.saveBool("_userIsAuthenticated", this.isAuthenticated);
        this.dataSetups.saveInt("_userCompanyId", this.companyId);
    }

    public void logout() {
        isAuthenticated = false;
        save();
    }
}
