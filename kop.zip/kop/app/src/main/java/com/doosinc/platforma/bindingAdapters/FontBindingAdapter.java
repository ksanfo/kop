package com.doosinc.platforma.bindingAdapters;

import android.graphics.Typeface;
import android.widget.EditText;
import android.widget.TextView;

import androidx.databinding.BindingAdapter;

import com.doosinc.platforma.tools.FontHelper;

public class FontBindingAdapter {
    @BindingAdapter("font_name")
    public static void chgFontTextView(TextView view, String fontName) {
        Typeface customFont = FontHelper.getFont(view.getContext(), fontName);
        if (customFont == null) {
            return;
        }
        view.setTypeface(customFont);
    }

    @BindingAdapter("font_name")
    public static void chgFontEditText(EditText view, String fontName) {
        Typeface customFont = FontHelper.getFont(view.getContext(), fontName);
        if (customFont == null) {
            return;
        }
        view.setTypeface(customFont);
    }
}
