package com.doosinc.platforma.pages;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager2.widget.ViewPager2;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.VideosPages;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.parcelables.ContentParcelable;

import java.util.ArrayList;

public class SelectedVideoContentPage extends AppCompatActivity {
    private Toolbar toolbar;
    private ArrayList<ContentParcelable> contents;
    private Integer selectedIndex;
    private Line line;
    private ViewPager2 pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        readArgument();

        setContentView(R.layout.video_contents_page);

        toolbar = findViewById(R.id.toolbar);
        initActionBar();

        pager = findViewById(R.id.contentPages);

        VideosPages pageAdapter = new VideosPages(contents);
        pager.setAdapter(pageAdapter);

        pager.setCurrentItem(selectedIndex, false);

        pageAdapter.setListener(new VideosPages.Listener() {
            @Override
            public void videoFinished(int position) {
                nextVideo(position);
            }
        });
    }

    private void nextVideo(int position) {
        position++;
        if (position >= contents.size()) {
            position = 0;
        }
        pager.setCurrentItem(position, false);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            bar.hide();
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            bar.show();
        }
    }

    private void readArgument() {
        Bundle argument = getIntent().getExtras();
        if (argument == null) {
            return;
        }

        line = (Line) argument.getSerializable(Line.class.getSimpleName());
        contents = argument.getParcelableArrayList("contents");
        selectedIndex = argument.getInt("selectedIndex");
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);

        bar.setTitle(line.getName());
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
