package com.doosinc.platforma.tools;

import com.doosinc.platforma.data.models.Company;
import java.util.ArrayList;

public class CompanyTools {


    public static Integer getCompanyId(Integer companyId, ArrayList<Company> companies) {
        if (companies == null || companies.isEmpty()) {
            return 0;
        }

        for (int i = 0; i < companies.size(); i++) {
            if (companyId.equals(companies.get(i).getId())) {
                return companyId;
            }
        }
        return companies.get(0).getId();
    }

    public static Company getCompanyById(Integer companyId, ArrayList<Company> companies) {
        if (companies == null) {
            return null;
        }

        for (int i = 0; i < companies.size(); i++) {
            if (companyId.equals(companies.get(i).getId())) {
                return companies.get(i);
            }
        }
        return null;
    }
}
