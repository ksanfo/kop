package com.doosinc.platforma.api;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.doosinc.platforma.api.classes.ApiData;
import com.doosinc.platforma.api.classes.ApiListener;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.api.modelParsers.CompanyContentParser;
import com.doosinc.platforma.api.modelParsers.CompanyParser;
import com.doosinc.platforma.api.modelParsers.ContentParser;
import com.doosinc.platforma.api.modelParsers.DayWithContentParser;
import com.doosinc.platforma.api.modelParsers.LineParser;
import com.doosinc.platforma.api.modelParsers.ProjectParser;
import com.doosinc.platforma.api.modelParsers.PromoFilterParser;
import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.DayWithContent;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.data.models.PromoFilter;
import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.api.modelParsers.UserParser;
import com.doosinc.platforma.setups.Constants;
import com.franmontiel.persistentcookiejar.ClearableCookieJar;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Api {
    private Context context;

    public Api(Context context) {
        this.context = context;
    }

    // Авторизация
    public void authUser(User user, final Context context, final ApiResult<User> listener) {
        JSONObject params = new JSONObject();
        try {
            params.put("email", user.getLogin());
            params.put("password", user.getPassword());
        } catch (JSONException e) {
            listener.completion(new Error(Error.CodeType.API, null), null);
            return;
        }

        String url = Constants.apiURL + "login";
        asyncPost(url, params, new ApiListener<JSONObject>(JSONObject.class) {
            @Override
            protected void completion(Error error, ApiData<JSONObject> data) {
                if (error != null) {
                    listener.completion(error, null);
                    return;
                }

                User user = UserParser.parse(data.payload, context);
                user.setAuthenticated(true);
                listener.completion(null, user);
            }
        });
    }

    // Получение списка компаний
    public void getCompanies(final ApiResult<ArrayList<Company>> listener) {
        String url = Constants.apiURL + "companies";
        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null);
                    return;
                }

                ArrayList<Company> companies = CompanyParser.parseList(data.payload);
                listener.completion(null, companies);
            }
        });
    }

    // Получение списка проектов
    public void getProjects(Integer companyId, final ApiResult<ArrayList<Project>> listener) {
        String url = Constants.apiURL + "/companies/" + companyId + "/projects/";
        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null);
                    return;
                }
                ArrayList<Project> projects = ProjectParser.parseList(data.payload);
                listener.completion(null, projects);
            }
        });
    }

    // Получение списка отрезков
    public void getLines(Integer projectId, final ApiResult<ArrayList<Line>> listener) {
        String url = Constants.apiURL + "/projects/" + projectId + "/lines";
        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null);
                    return;
                }
                ArrayList<Line> lines = LineParser.parseList(data.payload);
                listener.completion(null, lines);
            }
        });
    }

    // Получение списка контента
    public void getContents(Integer projectId,
                            Integer lineId,
                            Content.ContentType type,
                            String dateFrom,
                            String dateTo,
                            final ApiResultWithDate<ArrayList<Content>> listener) {

        String url = Constants.apiURL + "projects/" + projectId
                + "/lines/" + lineId
                + "/content/" + type.getType();
        HashMap<String, String> parameters = new HashMap<>();
        if (dateFrom != null) {
            parameters.put("dateFrom", dateFrom);
        }
        if (dateTo != null) {
            parameters.put("dateTo", dateTo);
        }

        asyncGet(url, parameters, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null, null);
                    return;
                }
                ArrayList<Content> contents = ContentParser.parseList(data.payload);
                String dateContent = data.rootJson.optString("date");
                listener.completion(null, contents, dateContent  );
            }
        });
    }

    //Получение списка дат с контентом
    public void getDateContent(Integer lineId,
                               Content.ContentType type, final ApiResult<ArrayList<DayWithContent>> listener){

        String url = Constants.apiURL + "/lines/" + lineId + "/content/" + type.getType() + "/calendar";

        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null);
                    return;
                }
                ArrayList<DayWithContent> contents = DayWithContentParser.parseList(data.payload);
                listener.completion(null, contents);
            }
        });
    }

    //Получение контента для Трансляции
    public void getStreamContent(Integer companyId,
                                 final ApiResult<ArrayList<CompanyContent>> listener){

        String url = Constants.apiURL + "companyContent/" + companyId + "/streams/";

        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null );
                    return;
                }
                ArrayList<CompanyContent> contents = CompanyContentParser.parseList(data.payload, CompanyContent.TypeSection.STREAM);
                listener.completion(null, contents );
            }
        });
    }

    // Получение Промо контента
    public void getPromoContent(Integer companyId,
                                HashMap<String,String> parameters,
                                 final ApiResult<ArrayList<CompanyContent>> listener){

        String url = Constants.apiURL + "companyContent/" + companyId + "/promo/";

        asyncGet(url, parameters, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null );
                    return;
                }
                ArrayList<CompanyContent> contents = CompanyContentParser.parseList(data.payload, CompanyContent.TypeSection.PROMO);
                listener.completion(null, contents );
            }
        });
    }

    // Получение Промо фильтра
    public void getPromoFilter(Integer companyId,
                                final ApiResult<ArrayList<PromoFilter>> listener){

        String url = Constants.apiURL + "companies/" + companyId + "/promoFilter/";

        asyncGet(url, null, new ApiListener<JSONArray>(JSONArray.class) {
            @Override
            protected void completion(Error error, ApiData<JSONArray> data) {
                if (error != null) {
                    listener.completion(error, null );
                    return;
                }
                ArrayList<PromoFilter> contents = PromoFilterParser.parseList(data.payload);
                listener.completion(null, contents );
            }
        });
    }

    private void  asyncGet(String url, HashMap<String, String> parameters, final ApiListener listener) {
        HttpUrl httpUrl = HttpUrl.parse(url);
        if (httpUrl == null) {
            return;
        }
        HttpUrl.Builder httpBuilder = httpUrl.newBuilder();
        if (parameters != null) {
            for (Map.Entry<String, String> entry : parameters.entrySet()) {
                httpBuilder.addQueryParameter(entry.getKey(), entry.getValue());
            }
        }

        Request request = new Request.Builder()
                .url(httpBuilder.build())
                .build();

        asyncCall(request, listener);
    }

    private void asyncPost(String url, JSONObject parameters, final ApiListener listener) {
        String json = parameters.toString();
        MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
        @SuppressWarnings("deprecation") RequestBody body = RequestBody.create(mediaType, json);

        final Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();


        asyncCall(request, listener);
    }

    private void asyncCall(final Request request, final ApiListener listener) {
        OkHttpClient client = getClient();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                listener.resultError(new Error(Error.CodeType.API, e.getMessage()));
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                listener.result(response);
            }
        });
    }

    private OkHttpClient getClient() {

        CookieManager cookieManager = new CookieManager();
        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);

        ClearableCookieJar cookieJar =
                new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(context));


        return new OkHttpClient.Builder()
                .connectTimeout(180, TimeUnit.SECONDS)
                .writeTimeout(180, TimeUnit.SECONDS)
                .readTimeout(180, TimeUnit.SECONDS)
                .cookieJar(cookieJar)
                .build();
    }

    public String[] getCookieForUrl(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpUrl httpUrl = new HttpUrl.Builder()
                    .scheme(url.getProtocol())
                    .host(url.getHost())
                    .build();

            List<Cookie> cokies = getClient().cookieJar().loadForRequest(httpUrl);
            String[] out = new String[cokies.size()];
            for (int i = 0; i < cokies.size(); i++) {
                out[i] = cokies.get(i).toString();
            }
            return out;

        } catch (MalformedURLException e) {
            Log.d("DINC", "getCookieForUrl error = " + e.getLocalizedMessage());
            return new String[]{};
        }
    }

    public interface ApiResult<T> {
        void completion(Error error, T data);
    }

    public interface ApiResultWithDate<T> {
        void completion(Error error, T data, String date);
    }
}
