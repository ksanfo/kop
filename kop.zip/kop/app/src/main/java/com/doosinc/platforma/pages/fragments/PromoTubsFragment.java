package com.doosinc.platforma.pages.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.CompanyContentList;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;
import com.doosinc.platforma.pages.MainPage;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;

import java.util.ArrayList;
import java.util.HashMap;

public class PromoTubsFragment extends Fragment {

    private ContentLoadingProgressBar progressBar;
    private CompanyContentList adapter;
    private ArrayList<CompanyContentParcelable> contents;
    private Company company;
    private String promoFilterId;

    public PromoTubsFragment(String promoFilterId){
        this.promoFilterId = promoFilterId;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.contents_list_fragment, container, false);
        progressBar = view.findViewById(R.id.progressBar);

        MainPage mainPage = (MainPage) getActivity();
        if (mainPage != null) {

            company = mainPage.company;
        }

        //noinspection Convert2Lambda,Anonymous2MethodRef
        adapter = new CompanyContentList(new CompanyContentList.Handler() {
            @Override
            public void selected(Integer index) {
                showContent(index);
            }
        });

        RecyclerView recyclerView = view.findViewById(R.id.list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        promoOperation(promoFilterId);
        return view;
    }

    private void showContent(Integer index) {

        Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        Router.showStreamContent(activity, index, contents, company);
    }

    private void promoOperation( String promoFilterId ){

        HashMap<String, String> parameters = new HashMap<>();
        parameters.put("filterId[]", promoFilterId);

        //noinspection Convert2Lambda
        new Api(getContext()).getPromoContent(company.getId(),parameters, new Api.ApiResult<ArrayList<CompanyContent>>() {
            @Override
            public void completion(final Error error, ArrayList<CompanyContent> data) {

                Activity activity = getActivity();
                if (activity == null) {
                    return;
                }
                //noinspection Convert2Lambda
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, getActivity());
                        } else {
                            done(data);
                        }
                    }
                });

            }
        });

    }
    private void done(ArrayList<CompanyContent> data){

        if ( data == null ) {
            return;
        }

        contents = new ArrayList<>();
        for(CompanyContent content : data) {
            CompanyContentParcelable companyContentParcelable = new CompanyContentParcelable(content);
            contents.add(companyContentParcelable);
        }
        adapter.setContents(contents);

    }
}
