package com.doosinc.platforma.api.classes;

import org.json.JSONObject;

public class ApiData<T> {
    public T payload;
    public JSONObject rootJson;
}
