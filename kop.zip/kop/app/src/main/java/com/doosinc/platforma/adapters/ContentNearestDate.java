package com.doosinc.platforma.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;

import com.doosinc.platforma.databinding.NearestDateCellBinding;


public class ContentNearestDate extends RecyclerView.Adapter<ContentNearestDate.ViewHolder> {

    private Handler handler;
    private String nearDay;


    public ContentNearestDate(String nearDay, Handler handler) {

        this.nearDay = nearDay;
        this.handler = handler;
    }

    public int getItemCount() {
        if (nearDay == null) {
            return 0;
        }
        return 1;
    }

    @NonNull
    public ContentNearestDate.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {

        LayoutInflater inflater = LayoutInflater.from( parent.getContext() );
        NearestDateCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.nearest_date_cell, parent, false);
        return new ViewHolder( binding );
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.binding.setNearDay(nearDay);
        holder.binding.setHandler(handler);
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        NearestDateCellBinding binding;

        ViewHolder( NearestDateCellBinding binding ) {
            super( binding.getRoot() );
            this.binding = binding;
        }
    }

    public interface Handler {
        void goToDay(String day);
    }
}
