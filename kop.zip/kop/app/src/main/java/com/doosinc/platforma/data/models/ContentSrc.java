package com.doosinc.platforma.data.models;

import androidx.annotation.Nullable;

import java.io.Serializable;

public class ContentSrc implements Serializable {
    @Nullable
    private String src = null;

    @Nullable
    private String tmb = null;

    @Nullable
    public String getSrc() {
        return src;
    }

    public void setSrc(@Nullable String src) {
        this.src = src;
    }

    @Nullable
    public String getTmb() {
        return tmb;
    }

    public void setTmb(@Nullable String tmb) {
        this.tmb = tmb;
    }
}
