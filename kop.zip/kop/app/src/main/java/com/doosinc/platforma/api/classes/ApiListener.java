package com.doosinc.platforma.api.classes;

import android.util.Log;

import com.doosinc.platforma.api.Api;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;

import okhttp3.Response;
import okhttp3.ResponseBody;

public abstract class ApiListener<T> {
    private final Class<T> type;

    protected ApiListener(Class<T> type) {
        this.type = type;
    }

    protected abstract void completion(Error error, ApiData<T> data);

    public void result(Response response) {
        int code = response.code();
        JSONObject jsonData = null;
        try {
            ResponseBody body = response.body();
            if (body != null) {
                String data = body.string();
                jsonData = new JSONObject(data);
            }
        } catch (Throwable t) {
            Log.d("DINC", "parse body " + t.getLocalizedMessage());
            completion(new Error(Error.CodeType.API, null), null);
            return;
        }

        if (response.code() == 401) {
            completion(new Error(Error.CodeType.AUTH, null), null);
            return;
        }

        Error error = parseErrors(code, jsonData);
        if (error != null) {
            resultError(error);
            return;
        }

        T payload = parsePayload(jsonData);
        if (payload == null) {
            completion(new Error(Error.CodeType.API, null), null);
            return;
        }

        ApiData<T> apiData = new ApiData<>();
        apiData.payload = payload;
        apiData.rootJson = jsonData;
        completion(null, apiData);
    }

    public void resultError(Error error) {
        completion(error, null);
    }

    private T parsePayload(JSONObject json) {
        if (json == null) {
            return null;
        }
        if (type.equals(JSONObject.class)) {
            return type.cast(json.opt("payload"));
        } else if (type.equals(JSONArray.class)) {
            return type.cast(json.optJSONArray("payload"));
        } else {
            Log.d("DINC", "unk. data type = " + type.getName());
            return null;
        }
    }

    private Error parseErrors(int code, JSONObject json) {
        if (code >= 500 && code <= 599) {
            return new Error(Error.CodeType.API, null);
        }

        if (json == null) {
            return new Error(Error.CodeType.API, null);
        }

        if (json.optBoolean("success")) {
            return null;
        }

        return new Error(Error.CodeType.OTHER, json.optString("error"));
    }
}