package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.data.models.Project;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProjectParser {
    public static ArrayList<Project> parseList(JSONArray jsonArray) {
        ArrayList<Project> projects = new ArrayList<>();
        if (jsonArray == null) {
            return projects;
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            Project project = new Project();
            project.setId(json.optInt("id"));
            project.setName(json.optString("name"));
            project.setDescr(json.optString("description"));


            ContentSrc image = ContentSrcParser.parse(json.optJSONObject("image"));
            project.setImage(image);

            projects.add(project);
        }


        return projects;
    }
}
