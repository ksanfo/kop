package com.doosinc.platforma;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.doosinc.platforma.router.Router;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Router.checkAuth( this );
    }
}
