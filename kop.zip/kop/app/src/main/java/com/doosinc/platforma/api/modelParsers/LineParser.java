package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.data.models.Line;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class LineParser {
    public static ArrayList<Line> parseList(JSONArray jsonArray) {
        ArrayList<Line> lines = new ArrayList<>();
        if (jsonArray == null) {
            return lines;
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            Line line = new Line();
            line.setId(json.optInt("id"));
            line.setName(json.optString("name"));
            line.setDescr(json.optString("description"));

            ContentSrc image = ContentSrcParser.parse(json.optJSONObject("image"));
            line.setImage(image);

            Content.ContentType[] tabs = LineParser.parseTabs(json.optJSONArray("tabs"));
            line.setTabs(tabs);

            lines.add(line);
        }


        return lines;
    }

    private static Content.ContentType[] parseTabs(JSONArray jsonArray) {
        if (jsonArray == null) {
            return new Content.ContentType[0];
        }

        Content.ContentType[] contents = new Content.ContentType[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            String typeStr = jsonArray.optString(i);
            Content.ContentType type = Content.ContentType.getType(typeStr);
            contents[i] = type;
        }

        return contents;
    }
}
