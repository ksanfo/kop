package com.doosinc.platforma.pages;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.ContentLoadingProgressBar;

import android.app.Activity;
import android.os.Bundle;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.exceptions.OutOfDateRangeException;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.doosinc.platforma.R;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.DayWithContent;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;
import com.doosinc.platforma.tools.DateConversion;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class CalendarPage extends AppCompatActivity {

    private CalendarView calendarView;
    private Line line;
    private int pagerCurrentItem;
    private Content.ContentType typeContent;
    private Toolbar toolbar;
    private String relevantDate;
    private DateConversion dateConversion;
    private ArrayList<String> dateContent =  new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readArgument();
        dateConversion = new DateConversion();
        setContentView(R.layout.calendar_page);
        toolbar = findViewById(R.id.toolbar);
        initActionBar();
        loadListDaysWithContent();

        calendarView = findViewById(R.id.calendarView);

        // for relevantDate
        colorizeDate();

        //noinspection Convert2Lambda,Anonymous2MethodRef
        calendarView.setOnDayClickListener(new OnDayClickListener() {

            @Override
            public void onDayClick(EventDay eventDay) {
                showContent(eventDay);
            }
        });
    }

    private void showContent(EventDay day) {

        if ( dateContent == null ) {
            return;
        }

        Activity activity = this;
        String eventDay = dateConversion.doStringFromDate(day.getCalendar().getTime());

        for (int i = 0; i < dateContent.size(); i++) {

            if(dateContent.get(i).equals(eventDay)){
                Router.showDayContent(activity, eventDay, pagerCurrentItem);
                return;
            }
        }

        List<Calendar> calendars = new ArrayList<>();
        calendars.add(day.getCalendar());
        calendarView.setDisabledDays(calendars);
    }

    private void readArgument() {
        Bundle argument = getIntent().getExtras();
        if (argument == null) {
            return;
        }
        typeContent = (Content.ContentType) argument.getSerializable("typeContent");
        line = (Line) argument.getSerializable(Line.class.getSimpleName());
        pagerCurrentItem = argument.getInt("pagerCurrentItem");
        relevantDate = argument.getString("relevantDate");
    }

    private void initActionBar() {
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar == null) {
            return;
        }

        bar.setDisplayHomeAsUpEnabled(true);
        bar.setDisplayShowHomeEnabled(true);

        bar.setTitle(line.getName());
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    public Calendar getLastDateOfMonth( Calendar referenceDate ) {

        int day = referenceDate.getActualMaximum(Calendar.DAY_OF_MONTH);
        int month = referenceDate.get(Calendar.MONTH);
        int year = referenceDate.get(Calendar.YEAR);

        return new GregorianCalendar(year, month, day);
    }

    public Calendar getFirstDateOfMonth( Calendar referenceDate) {

        int day = referenceDate.getActualMinimum(Calendar.DAY_OF_MONTH);
        int month = referenceDate.get(Calendar.MONTH);
        int year = referenceDate.get(Calendar.YEAR);

        return new GregorianCalendar(year, month, day);
    }

    void loadListDaysWithContent() {
        final ContentLoadingProgressBar progressBar = findViewById(R.id.progress_bar);

        //noinspection Convert2Lambda
        new Api(this).getDateContent(line.getId(), typeContent, new Api.ApiResult<ArrayList<DayWithContent>>() {
            @Override
            public void completion(Error error, ArrayList<DayWithContent> data) {

                //noinspection Convert2Lambda
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();

                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, CalendarPage.this);
                        } else {
                            doneCalendarMakeup(data);
                        }
                    }
                });
            }
        });
    }

    private void colorizeDate(){
        try {
            calendarView.setDate(dateConversion.doGregorianCalendar(relevantDate));
        } catch (OutOfDateRangeException e) {
            e.printStackTrace();
        }
    }

    private void doneCalendarMakeup(ArrayList<DayWithContent> data){

        if ( data == null ) {
            return;
        }
        ArrayList<Calendar> calendars = new ArrayList<>();
        for (int i = 0; i < data.size(); i++) {
            GregorianCalendar gregorianDay = data.get(i).getDay();
            calendars.add(gregorianDay);
            dateContent.add(dateConversion.doStingFromGregorianCalendarDash(gregorianDay));
        }
        if(calendars.size() < 1){
            return;
        }
        calendarView.setHighlightedDays(calendars);
        calendarView.setMinimumDate(getFirstDateOfMonth(calendars.get(calendars.size()-1)));
        calendarView.setMaximumDate(getLastDateOfMonth(calendars.get(0)));

        // for setMinimumDate - setMaximumDate
        colorizeDate();
    }

}