package com.doosinc.platforma.data.parcelables;

import android.os.Parcel;
import android.os.Parcelable;

import com.doosinc.platforma.data.models.CompanyContent;
import com.doosinc.platforma.data.models.ContentSrc;

public class CompanyContentParcelable implements Parcelable {

    private int id;
    private String descr;
    private String src;
    private String tmb;
    private CompanyContent.ContentType type;
    private CompanyContent.TypeSection typeSection;

    public CompanyContentParcelable(CompanyContent companyContent){

        id = companyContent.getId();
        descr = companyContent.getDescription();

        ContentSrc image = companyContent.getImage();
        if (image != null) {
            src = image.getSrc();
            tmb = image.getTmb();
        }
        type = companyContent.getType();
        typeSection = companyContent.getTypeSection();
    }

    private CompanyContentParcelable(Parcel in) {
        id = in.readInt();
        descr = in.readString();
        src = in.readString();
        tmb = in.readString();
        type = CompanyContent.ContentType.getType(in.readString());
        typeSection = CompanyContent.TypeSection.getType(in.readString());
    }

    public static final Creator<CompanyContentParcelable> CREATOR = new Creator<CompanyContentParcelable>() {
        @Override
        public CompanyContentParcelable createFromParcel(Parcel in) {
            return new CompanyContentParcelable(in);
        }

        @Override
        public CompanyContentParcelable[] newArray(int size) {
            return new CompanyContentParcelable[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(descr);
        dest.writeString(src);
        dest.writeString(tmb);
        dest.writeString(type.getType());
        dest.writeString(typeSection.getType());
    }

    public int getId() {
        return id;
    }

    public String getDescr() {
        return descr;
    }

    public String getSrc() {
        return src;
    }

    public String getTmb() {
        return tmb;
    }

    public CompanyContent.ContentType getType() {
        return type;
    }

    public CompanyContent.TypeSection getTypeSection() {
        return typeSection;
    }
}
