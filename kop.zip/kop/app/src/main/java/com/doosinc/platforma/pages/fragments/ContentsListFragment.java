package com.doosinc.platforma.pages.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.ContentNearestDate;
import com.doosinc.platforma.adapters.ContentsList;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Content;
import com.doosinc.platforma.data.models.DayWithContent;
import com.doosinc.platforma.data.models.Line;
import com.doosinc.platforma.data.models.Project;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.pages.ContentsPage;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;
import com.doosinc.platforma.tools.DateConversion;

import java.util.ArrayList;

public class ContentsListFragment extends Fragment {
    private Content.ContentType contentType;
    private Project project;
    private Line line;

    private ContentLoadingProgressBar progressBar;
    private ContentsList adapter;

    private ArrayList<ContentParcelable> contents;
    private RecyclerView recyclerView;
    private String dayWithContent;
    private CurrentDate currentDate;
    private int pagerCurrentItem;
   private UpdatePage updatePage;

    public ContentsListFragment(ContentsPage page, CurrentDate currentDate ){
        this.currentDate = currentDate;
        this.updatePage = page;
    }

    @SuppressWarnings({"Convert2Lambda", "Anonymous2MethodRef"})
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        readArguments();


        View view = inflater.inflate(R.layout.contents_list_fragment, container, false);

        progressBar = view.findViewById(R.id.progressBar);

        adapter = new  ContentsList(new ContentsList.Handler() {
            @Override
            public void selected(Integer index) {
                showContent(index);
            }
        });

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView = view.findViewById(R.id.list);
        recyclerView.setLayoutManager(layoutManager);

        loadData();
        return view;
    }

    private void showContent(Integer index) {
        Activity activity = getActivity();
        if (activity == null) {
            return;
        }

        ContentParcelable content = contents.get(index);
        Content.ContentType type = content.getType();
        if (type == Content.ContentType.IMAGE) {
            Router.showImageContent(activity, line, index, contents);
        } else {
            Router.showVideoContent(activity, line, index, contents);
        }
    }

    private void showContentNearestDate(String day){
        Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        updatePage.changeAdapter(new DateConversion().formatDateB(day), pagerCurrentItem);
    }

    @SuppressWarnings("Convert2Lambda")
    private void loadData() {
        progressBar.show();
        new Api(getContext()).getContents(project.getId(), line.getId(), contentType, dayWithContent, null, new Api.ApiResultWithDate<ArrayList<Content>>() {
            @Override
            public void completion(final Error error, final ArrayList<Content> data, final String date) {
                Activity activity = getActivity();
                if (activity == null) {
                    return;
                }
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.hide();
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, getActivity());
                        } else {
                            done(data, date);
                        }
                    }
                });
            }
        });
    }

    private void done( ArrayList<Content> data, String date) {

        if ( data == null ) {
            return;
        }

        contents = new ArrayList<>();
        for(Content content : data) {
            ContentParcelable contentParcelable = new ContentParcelable(content);
            contents.add(contentParcelable);
        }

         if(contents.size() == 0){
            searchNearestDateWithContent();
        }else {
            adapter.setContents(contents);
            recyclerView.setAdapter(adapter);
            currentDate.change(date);
        }
    }

    @SuppressWarnings("Convert2Lambda")
    private void searchNearestDateWithContent(){

        new Api(getContext()).getDateContent(line.getId(), contentType, new Api.ApiResult<ArrayList<DayWithContent>>() {
            @Override
            public void completion(Error error, ArrayList<DayWithContent> data) {
                Activity activity = getActivity();
                if (activity == null) {
                    return;
                }
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (error != null) {
                            ApiError.processingErrorsConnecting(error, getActivity());
                        } else {
                            doneNearestDate(data);
                        }
                    }
                });
            }

        });
    }

    private void doneNearestDate(ArrayList<DayWithContent> data){

        if (data == null) {
            return;
        }

        String nearDay = new DateConversion().doStingFromGregorianCalendar(data.get(0).getDay());
        //noinspection Convert2Lambda,Anonymous2MethodRef
        ContentNearestDate adapterNoContent = new ContentNearestDate(nearDay, new ContentNearestDate.Handler() {
            @Override
            public void goToDay(String day) {
                showContentNearestDate(day);
            }
        });
        recyclerView.setAdapter(adapterNoContent);
    }

    private void readArguments() {
        Bundle bundle = getArguments();
        if (bundle == null) {
            return;
        }

        contentType = (Content.ContentType) bundle.getSerializable("contentType");
        project = (Project) bundle.getSerializable(Project.class.getSimpleName());
        line = (Line) bundle.getSerializable(Line.class.getSimpleName());
        dayWithContent = bundle.getString("day");
        pagerCurrentItem = bundle.getInt("pagerCurrentItem");
    }

    public interface CurrentDate {
        void change(String toDay);
    }

    public interface UpdatePage {
        void changeAdapter(String toDay, int pagerCurrentItem);
    }

}
