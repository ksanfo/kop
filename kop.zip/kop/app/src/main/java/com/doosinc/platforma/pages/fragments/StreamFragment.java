package com.doosinc.platforma.pages.fragments;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.core.widget.ContentLoadingProgressBar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.doosinc.platforma.R;
import com.doosinc.platforma.adapters.CompanyContentList;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.api.classes.Error;
import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.CompanyContent;

import com.doosinc.platforma.data.models.User;
import com.doosinc.platforma.data.parcelables.CompanyContentParcelable;

import com.doosinc.platforma.pages.MainPage;
import com.doosinc.platforma.router.Router;
import com.doosinc.platforma.tools.ApiError;

import java.util.ArrayList;


public class StreamFragment extends Fragment {

    private ContentLoadingProgressBar progressBar;
    private ArrayList<CompanyContentParcelable> contents;
    private User user;
    private CompanyContentList adapter;
    private Company company;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView =
                inflater.inflate(R.layout.stream_fragment, container, false);

        progressBar = rootView.findViewById(R.id.progressBar);
        user = new User(getContext());

        MainPage mainPage = (MainPage) getActivity();
        if (mainPage != null) {

            company = mainPage.company;
        }

        //noinspection Convert2Lambda,Anonymous2MethodRef
        adapter = new CompanyContentList(new CompanyContentList.Handler() {
            @Override
            public void selected(Integer index) {
                showContent(index);
            }
        });

        RecyclerView recyclerView = rootView.findViewById(R.id.list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        streamOperation();

        return rootView;
    }

    private void showContent(Integer index) {
        Activity activity = getActivity();
        if (activity == null) {
            return;
        }
        Router.showStreamContent(activity, index, contents, company);
    }

    private void streamOperation(){
        progressBar.show();

        //noinspection Convert2Lambda
        new Api(getContext()).getStreamContent(user.getCompanyId(), new Api.ApiResult<ArrayList<CompanyContent>>() {
           @Override
           public void completion(final Error error, ArrayList<CompanyContent> data) {

               Activity activity = getActivity();
               if (activity == null) {
                   return;
               }

               //noinspection Convert2Lambda
               activity.runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                       progressBar.hide();
                       if (error != null) {
                           ApiError.processingErrorsConnecting(error, getActivity());
                       } else {
                           done(data);
                       }
                   }
               });

           }
       });

    }

    private void done(ArrayList<CompanyContent> data){

        if ( data == null ) {
            return;
        }

        contents = new ArrayList<>();
        for(CompanyContent content : data) {
            CompanyContentParcelable companyContentParcelable = new CompanyContentParcelable(content);
            contents.add(companyContentParcelable);
        }
        adapter.setContents(contents);
    }
}