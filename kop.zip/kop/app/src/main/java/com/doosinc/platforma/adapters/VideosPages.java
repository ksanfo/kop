package com.doosinc.platforma.adapters;

import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.databinding.VideoPageCellBinding;

import java.util.ArrayList;

public class VideosPages extends RecyclerView.Adapter<VideosPages.ViewHolder> {
    private ArrayList<ContentParcelable> contents;
    private Listener listener;

    public VideosPages(ArrayList<ContentParcelable> contents) {
        this.contents = contents;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public int getItemCount() {
        if (contents == null) {
            return 0;
        }

        return contents.size();
    }

    @NonNull
    public VideosPages.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        VideoPageCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.video_page_cell, parent, false);
        return new ViewHolder(binding);
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        ContentParcelable content = contents.get(position);
        holder.binding.setContent(content);

        holder.binding.player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                if (listener != null) {
                    listener.videoFinished(position);
                }
            }
        });
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        VideoPageCellBinding binding;

        ViewHolder(VideoPageCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface Listener {
        void videoFinished(int position);
    }
}
