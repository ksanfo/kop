package com.doosinc.platforma.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.doosinc.platforma.R;
import com.doosinc.platforma.data.parcelables.ContentParcelable;
import com.doosinc.platforma.databinding.ContentsCellBinding;

import java.util.ArrayList;

public class ContentsList extends RecyclerView.Adapter<ContentsList.ViewHolder> {
    private ArrayList<ContentParcelable> contents;
    private Handler handler;

    public ContentsList(Handler handler) {
        this.handler = handler;
    }

    public void setContents(ArrayList<ContentParcelable> contents) {
        this.contents = contents;
        notifyDataSetChanged();
    }

    public int getItemCount() {
        if (contents == null) {
            return 0;
        }

        double rows = Math.ceil(contents.size() / 2.0);
        return (int) rows;
    }

    @NonNull
    public ContentsList.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ContentsCellBinding binding = DataBindingUtil.inflate(inflater, R.layout.contents_cell, parent, false);
        return new ViewHolder(binding);
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Integer[] indexes = getIndexes(position);
        ContentParcelable[] pair = getLinesPair(indexes);

        holder.binding.setContentLeft(pair[0]);
        holder.binding.setContentLeftIndex(indexes[0]);

        holder.binding.setContentRight(pair[1]);
        holder.binding.setContentRightIndex(indexes[1]);

        holder.binding.setHandler(handler);
    }

    private Integer[] getIndexes(int position) {
        Integer[] indexes = new Integer[2];

        int lineIndex = position * 2;
        indexes[0] = lineIndex;

        if ((lineIndex + 1) < (contents.size())) {
            indexes[1] = lineIndex + 1;
        }

        return indexes;
    }

    private ContentParcelable[] getLinesPair(Integer[] indexes) {
        ContentParcelable[] pair = new ContentParcelable[2];

        pair[0] = contents.get(indexes[0]);

        if (indexes[1] != null) {
            pair[1] = contents.get(indexes[1]);
        }

        return pair;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ContentsCellBinding binding;

        ViewHolder(ContentsCellBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public interface Handler {
        void selected(Integer index);
    }

}
