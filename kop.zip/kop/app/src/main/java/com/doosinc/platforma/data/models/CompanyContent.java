package com.doosinc.platforma.data.models;

public class CompanyContent {
    public enum TypeSection {
        STREAM("STREAM"),
        PROMO("PROMO"),
        UNK("UNK");

        private String type;

        TypeSection(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        static public TypeSection getType(String type) {
            try {
                return valueOf(type);
            } catch (IllegalArgumentException e) {
                return UNK;
            }
        }
    }

    public enum ContentType {
        VIDEO("VIDEO"),
        UNK("UNK");

        private String type;

        ContentType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        static public ContentType getType(String type) {
            try {
                return valueOf(type);
            } catch (IllegalArgumentException e) {
                return UNK;
            }
        }
    }

    private Integer id;
    private String description;
    private ContentSrc image;
    private ContentType type;
    private TypeSection typeSection;
    private String date;
    
    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ContentSrc getImage() {
        return image;
    }

    public void setImage(ContentSrc image) {
        this.image = image;
    }

    public CompanyContent.ContentType getType() {
        return type;
    }

    public void setType(CompanyContent.ContentType type) {
        this.type = type;
    }

    public TypeSection getTypeSection() {
        return typeSection;
    }

    public void setTypeSection(TypeSection typeSection) {
        this.typeSection = typeSection;
    }
}

