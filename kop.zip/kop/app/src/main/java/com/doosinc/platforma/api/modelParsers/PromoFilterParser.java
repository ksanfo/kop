package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.PromoFilter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class PromoFilterParser {

    public static ArrayList<PromoFilter> parseList(JSONArray jsonArray) {
        ArrayList<PromoFilter> contents = new ArrayList<>();
        if (jsonArray == null) {
            return contents;
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            PromoFilter content = new PromoFilter();
            content.setId(json.optString("id"));
            content.setTitle(json.optString("title"));

            contents.add(content);
        }

        return contents;
    }

}
