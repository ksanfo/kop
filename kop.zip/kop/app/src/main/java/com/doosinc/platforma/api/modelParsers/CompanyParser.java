package com.doosinc.platforma.api.modelParsers;

import com.doosinc.platforma.data.models.Company;
import com.doosinc.platforma.data.models.ContentSrc;
import com.doosinc.platforma.data.models.Project;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CompanyParser {
    static public ArrayList<Company> parseList(JSONArray jsonArray) {
        ArrayList<Company> companies = new ArrayList<>();

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject json = jsonArray.optJSONObject(i);
            Company company = new Company();
            company.setId(json.optInt("id"));
            company.setName(json.optString("name"));

            Company.ContentType[] contents = CompanyParser.parseContentsList(json.optJSONArray("contents"));
            company.setContents(contents);

            ArrayList<Project> projects = ProjectParser.parseList(json.optJSONArray("projects"));
            company.setProjects(projects);

            ContentSrc image = ContentSrcParser.parse(json.optJSONObject("image"));
            company.setImage(image);

            companies.add(company);
        }


        return companies;
    }

    static private Company.ContentType[] parseContentsList(JSONArray contentsJson) {
        if (contentsJson == null) {
            return new Company.ContentType[0];
        }

        Company.ContentType[] contents = new Company.ContentType[contentsJson.length()];
        for (int i = 0; i < contentsJson.length(); i++) {
            String typeStr = contentsJson.optString(i);
            Company.ContentType type = Company.ContentType.getType(typeStr);
            contents[i] = type;
        }

        return contents;
    }
}
