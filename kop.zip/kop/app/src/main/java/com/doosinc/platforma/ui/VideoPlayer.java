package com.doosinc.platforma.ui;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.VideoView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.doosinc.platforma.R;
import com.doosinc.platforma.api.Api;
import com.doosinc.platforma.tools.GlideTools;

import java.util.HashMap;

public class VideoPlayer extends LinearLayout {
    private String videoUrl;
    private String placeholderUrl;

    private boolean looping;
    private VideoView videoView;
    private ImageView placeholderView;
    private ProgressBar progressBar;
    private MediaController mediaController;

    public VideoPlayer(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        readAttrs(context, attrs);
        loadView(context);
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
        loadVideo();
    }

    public void setPlaceholderUrl(String placeholderUrl) {
        this.placeholderUrl = placeholderUrl;
        loadPlaceholder();
    }

    public void setOnCompletionListener(MediaPlayer.OnCompletionListener onCompletionListener) {
        videoView.setOnCompletionListener(onCompletionListener);
    }

    public void setLooping(boolean looping) {
        this.looping = looping;
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        videoView.stopPlayback();
        videoView.setMediaController(null);
        mediaController = null;
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        placeholderView.setVisibility(VISIBLE);
        progressBar.setVisibility(VISIBLE);
        initVideo();
    }

    private void initVideo() {
        loadPlaceholder();
        loadVideo();
    }

    private void loadPlaceholder() {
        if (placeholderUrl == null) {
            return;
        }

        GlideUrl glideUrl = GlideTools.getUrl(getContext(), placeholderUrl);

        Glide.with(getContext())
                .load(glideUrl)
                .into(placeholderView);
    }

    private void loadVideo() {
        if (videoUrl == null) {
            return;
        }

        Uri videoUri = Uri.parse(videoUrl);

        String[] cookies = new Api(getContext()).getCookieForUrl(videoUrl);

        HashMap<String, String> headers = new HashMap<>();
        for(String cookie : cookies) {
            headers.put("Cookie", cookie);
        }

        videoView.setVideoURI(videoUri, headers);
        videoView.start();
    }

    private void readAttrs(Context context, @Nullable AttributeSet attrs) {
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.VideoPlayer,
                0, 0);

        try {
            videoUrl = a.getString(R.styleable.VideoPlayer_videoUrl);
            placeholderUrl = a.getString(R.styleable.VideoPlayer_placeholderUrl);
            looping = a.getBoolean(R.styleable.VideoPlayer_looping, false);
        } finally {
            a.recycle();
        }
    }

    private void loadView(Context context) {
        View v = View.inflate(context, R.layout.video_player_view, null);

        videoView = v.findViewById(R.id.videoView);
        placeholderView = v.findViewById(R.id.placeholder);
        progressBar = v.findViewById(R.id.progressBar);

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                showPlayer(mp);
            }
        });
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
            }
        });

        this.addView(v);
    }


    private void showPlayer(MediaPlayer mp) {
        mp.setLooping(looping);
        placeholderView.postDelayed(new Runnable() {
            @Override
            public void run() {
                placeholderView.setVisibility(GONE);
                progressBar.setVisibility(GONE);

                mediaController = new MediaController(getContext());
                mediaController.setAnchorView(VideoPlayer.this);
                videoView.setMediaController(mediaController);
            }
        }, 300);
    }
}
